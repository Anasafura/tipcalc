import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const tipcalc(),
    );
  }
}

class tipcalc extends StatefulWidget {
  const tipcalc({Key? key}) : super(key: key);

  @override
  _tipcalcState createState() => _tipcalcState();
}

class _tipcalcState extends State<tipcalc> {
  int _tipcoounter = 0;
  int _personcount = 1;
  double _amountbill = 0.0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: ListView(
          padding: EdgeInsets.all(20),
          scrollDirection: Axis.vertical,
          children: [
            Container(
              margin: EdgeInsets.only(
                  top: MediaQuery.of(context).size.height * 0.1),
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.0),
                  color: Colors.blueAccent.shade100),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10.0),
                    child: Text("Total Per Person Amount:-"),
                  ),
                  Text(
                    "\$ ${caltotalperson(_amountbill, _personcount)}",
                    style: TextStyle(
                        fontSize: 40.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.deepPurple),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              padding: EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                  color: Colors.transparent,
                  border:
                      Border.all(color: Colors.grey, style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(20.0)),
              child: Column(
                children: [
                  TextField(
                    keyboardType:
                        TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                        prefix: Text(
                          "Bill Amount-",
                          style: TextStyle(color: Colors.black),
                        ),
                        prefixIcon: Icon(Icons.attach_money)),
                    onChanged: (String value) {
                      try {
                        _amountbill = double.parse(value);
                      } catch (exception) {
                        _amountbill = 0.0;
                      }
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Split",
                          style: TextStyle(color: Colors.black),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              if (_personcount > 1) {
                                _personcount--;
                              }
                            });
                          },
                          child: Container(
                            width: 40,
                            height: 40,
                            margin: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: Colors.lightBlue.shade100,
                            ),
                            child: Center(
                              child: Text(
                                "-",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 40),
                              ),
                            ),
                          ),
                        ),
                        Text(
                          "$_personcount",
                          style: TextStyle(fontSize: 14.0),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              _personcount++;
                            });
                          },
                          child: Container(
                            width: 40,
                            height: 40,
                            margin: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: Colors.lightBlue.shade100,
                            ),
                            child: Center(
                              child: Text(
                                "+",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 30),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "TIP",
                          style: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                              "${caltotaltip(_amountbill, _personcount, _tipcoounter)}"),
                        ),
                      ],
                    ),
                  ),
                  Slider(
                      min: 0,
                      max: 100,
                      activeColor: Colors.deepPurpleAccent,
                      inactiveColor: Colors.grey,
                      value: _tipcoounter.toDouble(),
                      onChanged: (double newvalue) {
                        setState(() {
                          _tipcoounter = newvalue.round();
                        });
                      })
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  caltotalperson(double billAmount, int split) {
    double total =
        (billAmount + caltotaltip(billAmount, split, _tipcoounter)) / split;
    return total.toStringAsFixed(2);
  }

  caltotaltip(double billAmount, int split, int tippercent) {
    double totaltip = 0.0;
    if (billAmount < 0 || billAmount.toString().isEmpty || billAmount == null) {
    } else {
      totaltip = (billAmount * tippercent) / 100;
    }
    return totaltip.toStringAsFixed(2);
  }
}
